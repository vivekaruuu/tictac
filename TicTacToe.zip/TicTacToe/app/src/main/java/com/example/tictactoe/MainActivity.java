package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.example.tictactoe.MyCanvas.MyListener;
import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {

    MyCanvas mMyCanvas;
    TextView NameHolder1;
    TextView NameHolder2;
    static  String name1,name2;
    public void homeClick(View view){
        Intent intent=new Intent(getApplicationContext(),StartActivity.class);
        startActivity(intent);
        finish();
        MyCanvas.mAllShapes.clear();
        MyCanvas.mSelectedBoxes=new int[3][3];
        MyCanvas.mTurn=1;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mMyCanvas=findViewById(R.id.myCanvas);
        NameHolder1=findViewById(R.id.Name1);
        NameHolder2=findViewById(R.id.Name2);
        Intent intent=getIntent();
        name1= intent.getStringExtra("name1");
        name2=intent.getStringExtra("name2");
        NameHolder1.setText(name1);
        NameHolder2.setText(name2);


        mMyCanvas.setMyListener(new MyListener() {
            @Override
            public void updateMyText() {
                NameHolder1.setText(name1);
                NameHolder2.setText(name2);
            }
        });
    }


}
