package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;

public class StartActivity extends AppCompatActivity {

    TextInputLayout holder1;
    TextInputLayout holder2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startscreen);
        holder1=findViewById(R.id.holder1);
        holder2=findViewById(R.id.holder2);

    }
    private boolean validateHolder1(){
        String name1=holder1.getEditText().getText().toString().trim();
        if(name1.isEmpty()){
            holder1.setError("Field cant be empty");
            return false;
        }
        else if(name1.length()>7){
            holder1.setError("Name too long");
            return false;
        }
        else {
            holder1.setError(null);
            return true;
        }
    }
    private boolean validateHolder2() {
        String name2 = holder2.getEditText().getText().toString().trim();
        if (name2.isEmpty()) {
            holder2.setError("Field cant be empty");
            return false;
        } else if (name2.length() > 7) {
            holder2.setError("Name too long");
            return false;
        } else {
            holder2.setError(null);
            return true;
        }
    }
    public void OnClicked(View view){
        if(!validateHolder1()|!validateHolder2())
        {
            return;
        }
        String name1=holder1.getEditText().getText().toString().trim();
        String name2=holder2.getEditText().getText().toString().trim();
        Intent intent=new Intent(getApplicationContext(),MainActivity.class);
        intent.putExtra("name1",name1);
        intent.putExtra("name2",name2);
        startActivity(intent);
        finish();
    }
}
